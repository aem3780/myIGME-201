﻿
namespace ArcherLai_FinalProject
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.roommateHobbies2 = new System.Windows.Forms.Label();
            this.roommatePets = new System.Windows.Forms.Label();
            this.roommateStudy = new System.Windows.Forms.Label();
            this.roommateGuests = new System.Windows.Forms.Label();
            this.roommateActive = new System.Windows.Forms.Label();
            this.roommateWakeUp = new System.Windows.Forms.Label();
            this.roommateGenderPref = new System.Windows.Forms.Label();
            this.roommateYear = new System.Windows.Forms.Label();
            this.roommateGender = new System.Windows.Forms.Label();
            this.roommateAge = new System.Windows.Forms.Label();
            this.roommateMajor = new System.Windows.Forms.Label();
            this.roommateBed = new System.Windows.Forms.Label();
            this.roommateEmail = new System.Windows.Forms.Label();
            this.roommateName = new System.Windows.Forms.Label();
            this.roommateHobbies1 = new System.Windows.Forms.Label();
            this.roommatePictureBox = new System.Windows.Forms.PictureBox();
            this.petsLabel = new System.Windows.Forms.Label();
            this.hobbiesLabel = new System.Windows.Forms.Label();
            this.roomateGenderLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.studyLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.guestsLabel = new System.Windows.Forms.Label();
            this.majorLabel = new System.Windows.Forms.Label();
            this.wakeUpLabel = new System.Windows.Forms.Label();
            this.bedTimeLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.activeLabel = new System.Windows.Forms.Label();
            this.genderLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.matchButton = new System.Windows.Forms.Button();
            this.profileButton = new System.Windows.Forms.Button();
            this.homeButton = new System.Windows.Forms.Button();
            this.compatabilityLabel = new System.Windows.Forms.Label();
            this.compatibilityScore = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roommatePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.Transparent;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(805, 57);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "   Tiger Match";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Black;
            this.richTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.ForeColor = System.Drawing.Color.Transparent;
            this.richTextBox2.Location = new System.Drawing.Point(0, 45);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(805, 12);
            this.richTextBox2.TabIndex = 5;
            this.richTextBox2.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(23, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 304);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Roommate Matches:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Items.AddRange(new object[] {
            "Tommy Smith",
            "ArcherLai",
            "Allie Maus",
            "Jack Wade",
            "Abby Robinson",
            "Alex Miller",
            "Jenna Joyce"});
            this.listBox1.Location = new System.Drawing.Point(0, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(200, 260);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.compatibilityScore);
            this.groupBox2.Controls.Add(this.compatabilityLabel);
            this.groupBox2.Controls.Add(this.roommateHobbies2);
            this.groupBox2.Controls.Add(this.roommatePets);
            this.groupBox2.Controls.Add(this.roommateStudy);
            this.groupBox2.Controls.Add(this.roommateGuests);
            this.groupBox2.Controls.Add(this.roommateActive);
            this.groupBox2.Controls.Add(this.roommateWakeUp);
            this.groupBox2.Controls.Add(this.roommateGenderPref);
            this.groupBox2.Controls.Add(this.roommateYear);
            this.groupBox2.Controls.Add(this.roommateGender);
            this.groupBox2.Controls.Add(this.roommateAge);
            this.groupBox2.Controls.Add(this.roommateMajor);
            this.groupBox2.Controls.Add(this.roommateBed);
            this.groupBox2.Controls.Add(this.roommateEmail);
            this.groupBox2.Controls.Add(this.roommateName);
            this.groupBox2.Controls.Add(this.roommateHobbies1);
            this.groupBox2.Controls.Add(this.roommatePictureBox);
            this.groupBox2.Controls.Add(this.petsLabel);
            this.groupBox2.Controls.Add(this.hobbiesLabel);
            this.groupBox2.Controls.Add(this.roomateGenderLabel);
            this.groupBox2.Controls.Add(this.yearLabel);
            this.groupBox2.Controls.Add(this.studyLabel);
            this.groupBox2.Controls.Add(this.ageLabel);
            this.groupBox2.Controls.Add(this.guestsLabel);
            this.groupBox2.Controls.Add(this.majorLabel);
            this.groupBox2.Controls.Add(this.wakeUpLabel);
            this.groupBox2.Controls.Add(this.bedTimeLabel);
            this.groupBox2.Controls.Add(this.emailLabel);
            this.groupBox2.Controls.Add(this.activeLabel);
            this.groupBox2.Controls.Add(this.genderLabel);
            this.groupBox2.Controls.Add(this.nameLabel);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(284, 71);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(483, 333);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Roommate Profile";
            // 
            // roommateHobbies2
            // 
            this.roommateHobbies2.AutoSize = true;
            this.roommateHobbies2.Location = new System.Drawing.Point(297, 296);
            this.roommateHobbies2.Name = "roommateHobbies2";
            this.roommateHobbies2.Size = new System.Drawing.Size(165, 16);
            this.roommateHobbies2.TabIndex = 59;
            this.roommateHobbies2.Text = "Spending time with friends.";
            // 
            // roommatePets
            // 
            this.roommatePets.AutoSize = true;
            this.roommatePets.Location = new System.Drawing.Point(394, 258);
            this.roommatePets.Name = "roommatePets";
            this.roommatePets.Size = new System.Drawing.Size(32, 16);
            this.roommatePets.TabIndex = 57;
            this.roommatePets.Text = "Yes";
            // 
            // roommateStudy
            // 
            this.roommateStudy.AutoSize = true;
            this.roommateStudy.Location = new System.Drawing.Point(394, 236);
            this.roommateStudy.Name = "roommateStudy";
            this.roommateStudy.Size = new System.Drawing.Size(32, 16);
            this.roommateStudy.TabIndex = 57;
            this.roommateStudy.Text = "Yes";
            // 
            // roommateGuests
            // 
            this.roommateGuests.AutoSize = true;
            this.roommateGuests.Location = new System.Drawing.Point(394, 214);
            this.roommateGuests.Name = "roommateGuests";
            this.roommateGuests.Size = new System.Drawing.Size(32, 16);
            this.roommateGuests.TabIndex = 57;
            this.roommateGuests.Text = "Yes";
            // 
            // roommateActive
            // 
            this.roommateActive.AutoSize = true;
            this.roommateActive.Location = new System.Drawing.Point(394, 191);
            this.roommateActive.Name = "roommateActive";
            this.roommateActive.Size = new System.Drawing.Size(56, 16);
            this.roommateActive.TabIndex = 58;
            this.roommateActive.Text = "Morning";
            // 
            // roommateWakeUp
            // 
            this.roommateWakeUp.AutoSize = true;
            this.roommateWakeUp.Location = new System.Drawing.Point(394, 167);
            this.roommateWakeUp.Name = "roommateWakeUp";
            this.roommateWakeUp.Size = new System.Drawing.Size(51, 16);
            this.roommateWakeUp.TabIndex = 56;
            this.roommateWakeUp.Text = "8:00am";
            // 
            // roommateGenderPref
            // 
            this.roommateGenderPref.AutoSize = true;
            this.roommateGenderPref.Location = new System.Drawing.Point(8, 309);
            this.roommateGenderPref.Name = "roommateGenderPref";
            this.roommateGenderPref.Size = new System.Drawing.Size(115, 16);
            this.roommateGenderPref.TabIndex = 57;
            this.roommateGenderPref.Text = "Male Roommates";
            // 
            // roommateYear
            // 
            this.roommateYear.AutoSize = true;
            this.roommateYear.Location = new System.Drawing.Point(57, 271);
            this.roommateYear.Name = "roommateYear";
            this.roommateYear.Size = new System.Drawing.Size(79, 16);
            this.roommateYear.TabIndex = 55;
            this.roommateYear.Text = "Sophomore";
            // 
            // roommateGender
            // 
            this.roommateGender.AutoSize = true;
            this.roommateGender.Location = new System.Drawing.Point(59, 250);
            this.roommateGender.Name = "roommateGender";
            this.roommateGender.Size = new System.Drawing.Size(38, 16);
            this.roommateGender.TabIndex = 56;
            this.roommateGender.Text = "Male";
            // 
            // roommateAge
            // 
            this.roommateAge.AutoSize = true;
            this.roommateAge.Location = new System.Drawing.Point(57, 230);
            this.roommateAge.Name = "roommateAge";
            this.roommateAge.Size = new System.Drawing.Size(22, 16);
            this.roommateAge.TabIndex = 55;
            this.roommateAge.Text = "19";
            // 
            // roommateMajor
            // 
            this.roommateMajor.AutoSize = true;
            this.roommateMajor.Location = new System.Drawing.Point(57, 208);
            this.roommateMajor.Name = "roommateMajor";
            this.roommateMajor.Size = new System.Drawing.Size(118, 16);
            this.roommateMajor.TabIndex = 55;
            this.roommateMajor.Text = "Computer Science";
            // 
            // roommateBed
            // 
            this.roommateBed.AutoSize = true;
            this.roommateBed.Location = new System.Drawing.Point(394, 143);
            this.roommateBed.Name = "roommateBed";
            this.roommateBed.Size = new System.Drawing.Size(58, 16);
            this.roommateBed.TabIndex = 55;
            this.roommateBed.Text = "10:00pm";
            // 
            // roommateEmail
            // 
            this.roommateEmail.AutoSize = true;
            this.roommateEmail.Location = new System.Drawing.Point(59, 188);
            this.roommateEmail.Name = "roommateEmail";
            this.roommateEmail.Size = new System.Drawing.Size(107, 16);
            this.roommateEmail.TabIndex = 54;
            this.roommateEmail.Text = "tms2536@rit.edu";
            // 
            // roommateName
            // 
            this.roommateName.AutoSize = true;
            this.roommateName.Location = new System.Drawing.Point(59, 167);
            this.roommateName.Name = "roommateName";
            this.roommateName.Size = new System.Drawing.Size(90, 16);
            this.roommateName.TabIndex = 54;
            this.roommateName.Text = "Tommy Smith";
            // 
            // roommateHobbies1
            // 
            this.roommateHobbies1.AutoSize = true;
            this.roommateHobbies1.Location = new System.Drawing.Point(297, 280);
            this.roommateHobbies1.Name = "roommateHobbies1";
            this.roommateHobbies1.Size = new System.Drawing.Size(180, 16);
            this.roommateHobbies1.TabIndex = 53;
            this.roommateHobbies1.Text = "Reading, soccer and coding.";
            // 
            // roommatePictureBox
            // 
            this.roommatePictureBox.ImageLocation = "https://images.unsplash.com/photo-1545696968-1a5245650b36?ixid=MnwxMjA3fDB8MHxwaG" +
    "90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1317&q=80";
            this.roommatePictureBox.Location = new System.Drawing.Point(11, 21);
            this.roommatePictureBox.Name = "roommatePictureBox";
            this.roommatePictureBox.Size = new System.Drawing.Size(148, 138);
            this.roommatePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.roommatePictureBox.TabIndex = 52;
            this.roommatePictureBox.TabStop = false;
            // 
            // petsLabel
            // 
            this.petsLabel.AutoSize = true;
            this.petsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petsLabel.Location = new System.Drawing.Point(228, 258);
            this.petsLabel.Name = "petsLabel";
            this.petsLabel.Size = new System.Drawing.Size(111, 16);
            this.petsLabel.TabIndex = 50;
            this.petsLabel.Text = "Are pets allowed:";
            // 
            // hobbiesLabel
            // 
            this.hobbiesLabel.AutoSize = true;
            this.hobbiesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hobbiesLabel.Location = new System.Drawing.Point(228, 280);
            this.hobbiesLabel.Name = "hobbiesLabel";
            this.hobbiesLabel.Size = new System.Drawing.Size(63, 16);
            this.hobbiesLabel.TabIndex = 35;
            this.hobbiesLabel.Text = "Hobbies:";
            // 
            // roomateGenderLabel
            // 
            this.roomateGenderLabel.AutoSize = true;
            this.roomateGenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomateGenderLabel.Location = new System.Drawing.Point(8, 289);
            this.roomateGenderLabel.Name = "roomateGenderLabel";
            this.roomateGenderLabel.Size = new System.Drawing.Size(181, 16);
            this.roomateGenderLabel.TabIndex = 49;
            this.roomateGenderLabel.Text = "Roomate gender preference:";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(8, 268);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(40, 16);
            this.yearLabel.TabIndex = 39;
            this.yearLabel.Text = "Year:";
            // 
            // studyLabel
            // 
            this.studyLabel.AutoSize = true;
            this.studyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studyLabel.Location = new System.Drawing.Point(228, 236);
            this.studyLabel.Name = "studyLabel";
            this.studyLabel.Size = new System.Drawing.Size(161, 16);
            this.studyLabel.TabIndex = 48;
            this.studyLabel.Text = "Will you study in the room:";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageLabel.Location = new System.Drawing.Point(8, 228);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(36, 16);
            this.ageLabel.TabIndex = 38;
            this.ageLabel.Text = "Age:";
            // 
            // guestsLabel
            // 
            this.guestsLabel.AutoSize = true;
            this.guestsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guestsLabel.Location = new System.Drawing.Point(228, 214);
            this.guestsLabel.Name = "guestsLabel";
            this.guestsLabel.Size = new System.Drawing.Size(125, 16);
            this.guestsLabel.TabIndex = 47;
            this.guestsLabel.Text = "Are guests allowed:";
            // 
            // majorLabel
            // 
            this.majorLabel.AutoSize = true;
            this.majorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.majorLabel.Location = new System.Drawing.Point(7, 208);
            this.majorLabel.Name = "majorLabel";
            this.majorLabel.Size = new System.Drawing.Size(45, 16);
            this.majorLabel.TabIndex = 37;
            this.majorLabel.Text = "Major:";
            // 
            // wakeUpLabel
            // 
            this.wakeUpLabel.AutoSize = true;
            this.wakeUpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wakeUpLabel.Location = new System.Drawing.Point(228, 167);
            this.wakeUpLabel.Name = "wakeUpLabel";
            this.wakeUpLabel.Size = new System.Drawing.Size(86, 16);
            this.wakeUpLabel.TabIndex = 46;
            this.wakeUpLabel.Text = "Wakes up at:";
            // 
            // bedTimeLabel
            // 
            this.bedTimeLabel.AutoSize = true;
            this.bedTimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bedTimeLabel.Location = new System.Drawing.Point(228, 143);
            this.bedTimeLabel.Name = "bedTimeLabel";
            this.bedTimeLabel.Size = new System.Drawing.Size(99, 16);
            this.bedTimeLabel.TabIndex = 45;
            this.bedTimeLabel.Text = "Goes to bed at:";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLabel.Location = new System.Drawing.Point(7, 188);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(45, 16);
            this.emailLabel.TabIndex = 36;
            this.emailLabel.Text = "Email:";
            // 
            // activeLabel
            // 
            this.activeLabel.AutoSize = true;
            this.activeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeLabel.Location = new System.Drawing.Point(228, 191);
            this.activeLabel.Name = "activeLabel";
            this.activeLabel.Size = new System.Drawing.Size(140, 16);
            this.activeLabel.TabIndex = 44;
            this.activeLabel.Text = "Most active during the:";
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderLabel.Location = new System.Drawing.Point(7, 248);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(56, 16);
            this.genderLabel.TabIndex = 35;
            this.genderLabel.Text = "Gender:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(7, 167);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(48, 16);
            this.nameLabel.TabIndex = 34;
            this.nameLabel.Text = "Name:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(685, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Match!";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // matchButton
            // 
            this.matchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.matchButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.matchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matchButton.ForeColor = System.Drawing.Color.White;
            this.matchButton.Location = new System.Drawing.Point(711, 13);
            this.matchButton.Name = "matchButton";
            this.matchButton.Size = new System.Drawing.Size(75, 23);
            this.matchButton.TabIndex = 20;
            this.matchButton.Text = "Match";
            this.matchButton.UseVisualStyleBackColor = false;
            // 
            // profileButton
            // 
            this.profileButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.profileButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.profileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileButton.ForeColor = System.Drawing.Color.White;
            this.profileButton.Location = new System.Drawing.Point(630, 13);
            this.profileButton.Name = "profileButton";
            this.profileButton.Size = new System.Drawing.Size(75, 23);
            this.profileButton.TabIndex = 19;
            this.profileButton.Text = "Profile";
            this.profileButton.UseVisualStyleBackColor = false;
            // 
            // homeButton
            // 
            this.homeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.homeButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.homeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeButton.ForeColor = System.Drawing.Color.White;
            this.homeButton.Location = new System.Drawing.Point(549, 13);
            this.homeButton.Name = "homeButton";
            this.homeButton.Size = new System.Drawing.Size(75, 23);
            this.homeButton.TabIndex = 18;
            this.homeButton.Text = "Home";
            this.homeButton.UseVisualStyleBackColor = false;
            // 
            // compatabilityLabel
            // 
            this.compatabilityLabel.AutoSize = true;
            this.compatabilityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compatabilityLabel.Location = new System.Drawing.Point(227, 71);
            this.compatabilityLabel.Name = "compatabilityLabel";
            this.compatabilityLabel.Size = new System.Drawing.Size(122, 20);
            this.compatabilityLabel.TabIndex = 21;
            this.compatabilityLabel.Text = "Compatability:";
            // 
            // compatibilityScore
            // 
            this.compatibilityScore.AutoSize = true;
            this.compatibilityScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compatibilityScore.Location = new System.Drawing.Point(393, 71);
            this.compatibilityScore.Name = "compatibilityScore";
            this.compatibilityScore.Size = new System.Drawing.Size(41, 20);
            this.compatibilityScore.TabIndex = 21;
            this.compatibilityScore.Text = "95%";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.matchButton);
            this.Controls.Add(this.profileButton);
            this.Controls.Add(this.homeButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form3";
            this.Text = "Match";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roommatePictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button matchButton;
        private System.Windows.Forms.Button profileButton;
        private System.Windows.Forms.Button homeButton;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label majorLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label hobbiesLabel;
        private System.Windows.Forms.Label petsLabel;
        private System.Windows.Forms.Label roomateGenderLabel;
        private System.Windows.Forms.Label studyLabel;
        private System.Windows.Forms.Label guestsLabel;
        private System.Windows.Forms.Label wakeUpLabel;
        private System.Windows.Forms.Label bedTimeLabel;
        private System.Windows.Forms.Label activeLabel;
        private System.Windows.Forms.PictureBox roommatePictureBox;
        private System.Windows.Forms.Label roommateMajor;
        private System.Windows.Forms.Label roommateBed;
        private System.Windows.Forms.Label roommateEmail;
        private System.Windows.Forms.Label roommateName;
        private System.Windows.Forms.Label roommateHobbies1;
        private System.Windows.Forms.Label roommateAge;
        private System.Windows.Forms.Label roommateHobbies2;
        private System.Windows.Forms.Label roommatePets;
        private System.Windows.Forms.Label roommateStudy;
        private System.Windows.Forms.Label roommateGuests;
        private System.Windows.Forms.Label roommateActive;
        private System.Windows.Forms.Label roommateWakeUp;
        private System.Windows.Forms.Label roommateGenderPref;
        private System.Windows.Forms.Label roommateYear;
        private System.Windows.Forms.Label roommateGender;
        private System.Windows.Forms.Label compatibilityScore;
        private System.Windows.Forms.Label compatabilityLabel;
    }
}