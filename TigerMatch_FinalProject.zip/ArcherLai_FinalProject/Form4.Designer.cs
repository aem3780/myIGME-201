﻿
namespace ArcherLai_FinalProject
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.matchButton = new System.Windows.Forms.Button();
            this.profileButton = new System.Windows.Forms.Button();
            this.homeButton = new System.Windows.Forms.Button();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.genderTextBox = new System.Windows.Forms.TextBox();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.majorTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.ageLabel = new System.Windows.Forms.Label();
            this.majorLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.genderLabel = new System.Windows.Forms.Label();
            this.hobbiesRichTextBox = new System.Windows.Forms.RichTextBox();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.hobbiesLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.genderPrefTextBox = new System.Windows.Forms.TextBox();
            this.studyTextBox = new System.Windows.Forms.TextBox();
            this.guestsTextBox = new System.Windows.Forms.TextBox();
            this.activeTextBox = new System.Windows.Forms.TextBox();
            this.wakeUpTextBox = new System.Windows.Forms.TextBox();
            this.bedTimeTextBox = new System.Windows.Forms.TextBox();
            this.petsTextBox = new System.Windows.Forms.TextBox();
            this.petsLabel = new System.Windows.Forms.Label();
            this.roomateGenderLabel = new System.Windows.Forms.Label();
            this.studyLabel = new System.Windows.Forms.Label();
            this.guestsLabel = new System.Windows.Forms.Label();
            this.wakeUpLabel = new System.Windows.Forms.Label();
            this.bedTimeLabel = new System.Windows.Forms.Label();
            this.activeLabel = new System.Windows.Forms.Label();
            this.profilePictureBox = new System.Windows.Forms.PictureBox();
            this.editPhotoButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.Transparent;
            this.richTextBox1.Location = new System.Drawing.Point(-3, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(805, 57);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "   Tiger Profile";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Black;
            this.richTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.ForeColor = System.Drawing.Color.Transparent;
            this.richTextBox2.Location = new System.Drawing.Point(-3, 45);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(805, 12);
            this.richTextBox2.TabIndex = 5;
            this.richTextBox2.Text = "";
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.submitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.submitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButton.ForeColor = System.Drawing.Color.Black;
            this.submitButton.Location = new System.Drawing.Point(713, 406);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(75, 23);
            this.submitButton.TabIndex = 6;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.SubmitButton__Click);
            // 
            // matchButton
            // 
            this.matchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.matchButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.matchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matchButton.ForeColor = System.Drawing.Color.White;
            this.matchButton.Location = new System.Drawing.Point(711, 13);
            this.matchButton.Name = "matchButton";
            this.matchButton.Size = new System.Drawing.Size(75, 23);
            this.matchButton.TabIndex = 20;
            this.matchButton.Text = "Match";
            this.matchButton.UseVisualStyleBackColor = false;
            // 
            // profileButton
            // 
            this.profileButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.profileButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.profileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileButton.ForeColor = System.Drawing.Color.White;
            this.profileButton.Location = new System.Drawing.Point(630, 13);
            this.profileButton.Name = "profileButton";
            this.profileButton.Size = new System.Drawing.Size(75, 23);
            this.profileButton.TabIndex = 19;
            this.profileButton.Text = "Profile";
            this.profileButton.UseVisualStyleBackColor = false;
            // 
            // homeButton
            // 
            this.homeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.homeButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.homeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeButton.ForeColor = System.Drawing.Color.White;
            this.homeButton.Location = new System.Drawing.Point(549, 13);
            this.homeButton.Name = "homeButton";
            this.homeButton.Size = new System.Drawing.Size(75, 23);
            this.homeButton.TabIndex = 18;
            this.homeButton.Text = "Home";
            this.homeButton.UseVisualStyleBackColor = false;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(88, 75);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(143, 20);
            this.nameTextBox.TabIndex = 22;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(22, 76);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(59, 19);
            this.nameLabel.TabIndex = 21;
            this.nameLabel.Text = "Name:";
            // 
            // genderTextBox
            // 
            this.genderTextBox.Location = new System.Drawing.Point(101, 224);
            this.genderTextBox.Name = "genderTextBox";
            this.genderTextBox.Size = new System.Drawing.Size(131, 20);
            this.genderTextBox.TabIndex = 32;
            // 
            // ageTextBox
            // 
            this.ageTextBox.Location = new System.Drawing.Point(89, 186);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(143, 20);
            this.ageTextBox.TabIndex = 31;
            // 
            // majorTextBox
            // 
            this.majorTextBox.Location = new System.Drawing.Point(89, 147);
            this.majorTextBox.Name = "majorTextBox";
            this.majorTextBox.Size = new System.Drawing.Size(143, 20);
            this.majorTextBox.TabIndex = 30;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(89, 110);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(143, 20);
            this.emailTextBox.TabIndex = 29;
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageLabel.Location = new System.Drawing.Point(24, 185);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(45, 19);
            this.ageLabel.TabIndex = 28;
            this.ageLabel.Text = "Age:";
            // 
            // majorLabel
            // 
            this.majorLabel.AutoSize = true;
            this.majorLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.majorLabel.Location = new System.Drawing.Point(24, 148);
            this.majorLabel.Name = "majorLabel";
            this.majorLabel.Size = new System.Drawing.Size(57, 19);
            this.majorLabel.TabIndex = 27;
            this.majorLabel.Text = "Major:";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLabel.Location = new System.Drawing.Point(24, 109);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(57, 19);
            this.emailLabel.TabIndex = 26;
            this.emailLabel.Text = "Email:";
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderLabel.Location = new System.Drawing.Point(24, 223);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(71, 19);
            this.genderLabel.TabIndex = 25;
            this.genderLabel.Text = "Gender:";
            // 
            // hobbiesRichTextBox
            // 
            this.hobbiesRichTextBox.Location = new System.Drawing.Point(28, 325);
            this.hobbiesRichTextBox.Name = "hobbiesRichTextBox";
            this.hobbiesRichTextBox.Size = new System.Drawing.Size(349, 108);
            this.hobbiesRichTextBox.TabIndex = 36;
            this.hobbiesRichTextBox.Text = "";
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(89, 258);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(143, 20);
            this.yearTextBox.TabIndex = 35;
            // 
            // hobbiesLabel
            // 
            this.hobbiesLabel.AutoSize = true;
            this.hobbiesLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hobbiesLabel.Location = new System.Drawing.Point(24, 290);
            this.hobbiesLabel.Name = "hobbiesLabel";
            this.hobbiesLabel.Size = new System.Drawing.Size(79, 19);
            this.hobbiesLabel.TabIndex = 34;
            this.hobbiesLabel.Text = "Hobbies:";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(24, 257);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(48, 19);
            this.yearLabel.TabIndex = 33;
            this.yearLabel.Text = "Year:";
            // 
            // genderPrefTextBox
            // 
            this.genderPrefTextBox.Location = new System.Drawing.Point(662, 322);
            this.genderPrefTextBox.Name = "genderPrefTextBox";
            this.genderPrefTextBox.Size = new System.Drawing.Size(127, 20);
            this.genderPrefTextBox.TabIndex = 50;
            // 
            // studyTextBox
            // 
            this.studyTextBox.Location = new System.Drawing.Point(646, 232);
            this.studyTextBox.Name = "studyTextBox";
            this.studyTextBox.Size = new System.Drawing.Size(143, 20);
            this.studyTextBox.TabIndex = 49;
            // 
            // guestsTextBox
            // 
            this.guestsTextBox.Location = new System.Drawing.Point(646, 194);
            this.guestsTextBox.Name = "guestsTextBox";
            this.guestsTextBox.Size = new System.Drawing.Size(143, 20);
            this.guestsTextBox.TabIndex = 48;
            // 
            // activeTextBox
            // 
            this.activeTextBox.Location = new System.Drawing.Point(646, 157);
            this.activeTextBox.Name = "activeTextBox";
            this.activeTextBox.Size = new System.Drawing.Size(143, 20);
            this.activeTextBox.TabIndex = 47;
            // 
            // wakeUpTextBox
            // 
            this.wakeUpTextBox.Location = new System.Drawing.Point(646, 118);
            this.wakeUpTextBox.Name = "wakeUpTextBox";
            this.wakeUpTextBox.Size = new System.Drawing.Size(143, 20);
            this.wakeUpTextBox.TabIndex = 46;
            // 
            // bedTimeTextBox
            // 
            this.bedTimeTextBox.Location = new System.Drawing.Point(646, 73);
            this.bedTimeTextBox.Name = "bedTimeTextBox";
            this.bedTimeTextBox.Size = new System.Drawing.Size(143, 20);
            this.bedTimeTextBox.TabIndex = 45;
            // 
            // petsTextBox
            // 
            this.petsTextBox.Location = new System.Drawing.Point(633, 277);
            this.petsTextBox.Name = "petsTextBox";
            this.petsTextBox.Size = new System.Drawing.Size(156, 20);
            this.petsTextBox.TabIndex = 44;
            // 
            // petsLabel
            // 
            this.petsLabel.AutoSize = true;
            this.petsLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petsLabel.Location = new System.Drawing.Point(428, 278);
            this.petsLabel.Name = "petsLabel";
            this.petsLabel.Size = new System.Drawing.Size(145, 19);
            this.petsLabel.TabIndex = 43;
            this.petsLabel.Text = "Are pets allowed?";
            // 
            // roomateGenderLabel
            // 
            this.roomateGenderLabel.AutoSize = true;
            this.roomateGenderLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomateGenderLabel.Location = new System.Drawing.Point(428, 323);
            this.roomateGenderLabel.Name = "roomateGenderLabel";
            this.roomateGenderLabel.Size = new System.Drawing.Size(228, 19);
            this.roomateGenderLabel.TabIndex = 42;
            this.roomateGenderLabel.Text = "Roomate gender preference:";
            // 
            // studyLabel
            // 
            this.studyLabel.AutoSize = true;
            this.studyLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studyLabel.Location = new System.Drawing.Point(428, 231);
            this.studyLabel.Name = "studyLabel";
            this.studyLabel.Size = new System.Drawing.Size(216, 19);
            this.studyLabel.TabIndex = 41;
            this.studyLabel.Text = "Will you study in the room?";
            // 
            // guestsLabel
            // 
            this.guestsLabel.AutoSize = true;
            this.guestsLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guestsLabel.Location = new System.Drawing.Point(428, 193);
            this.guestsLabel.Name = "guestsLabel";
            this.guestsLabel.Size = new System.Drawing.Size(164, 19);
            this.guestsLabel.TabIndex = 40;
            this.guestsLabel.Text = "Are guests allowed?";
            // 
            // wakeUpLabel
            // 
            this.wakeUpLabel.AutoSize = true;
            this.wakeUpLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wakeUpLabel.Location = new System.Drawing.Point(428, 117);
            this.wakeUpLabel.Name = "wakeUpLabel";
            this.wakeUpLabel.Size = new System.Drawing.Size(188, 19);
            this.wakeUpLabel.TabIndex = 39;
            this.wakeUpLabel.Text = "When do you wake up?";
            // 
            // bedTimeLabel
            // 
            this.bedTimeLabel.AutoSize = true;
            this.bedTimeLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bedTimeLabel.Location = new System.Drawing.Point(428, 74);
            this.bedTimeLabel.Name = "bedTimeLabel";
            this.bedTimeLabel.Size = new System.Drawing.Size(196, 19);
            this.bedTimeLabel.TabIndex = 38;
            this.bedTimeLabel.Text = "When do you go to bed?";
            // 
            // activeLabel
            // 
            this.activeLabel.AutoSize = true;
            this.activeLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeLabel.Location = new System.Drawing.Point(428, 156);
            this.activeLabel.Name = "activeLabel";
            this.activeLabel.Size = new System.Drawing.Size(215, 19);
            this.activeLabel.TabIndex = 37;
            this.activeLabel.Text = "When are you most active?";
            // 
            // profilePictureBox
            // 
            this.profilePictureBox.ImageLocation = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_7" +
    "20.png";
            this.profilePictureBox.Location = new System.Drawing.Point(262, 76);
            this.profilePictureBox.Name = "profilePictureBox";
            this.profilePictureBox.Size = new System.Drawing.Size(148, 138);
            this.profilePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.profilePictureBox.TabIndex = 51;
            this.profilePictureBox.TabStop = false;
            // 
            // editPhotoButton
            // 
            this.editPhotoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(105)))), ((int)(((byte)(2)))));
            this.editPhotoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.editPhotoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editPhotoButton.Location = new System.Drawing.Point(294, 224);
            this.editPhotoButton.Name = "editPhotoButton";
            this.editPhotoButton.Size = new System.Drawing.Size(97, 32);
            this.editPhotoButton.TabIndex = 52;
            this.editPhotoButton.Text = "Edit Photo";
            this.editPhotoButton.UseVisualStyleBackColor = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.editPhotoButton);
            this.Controls.Add(this.profilePictureBox);
            this.Controls.Add(this.genderPrefTextBox);
            this.Controls.Add(this.studyTextBox);
            this.Controls.Add(this.guestsTextBox);
            this.Controls.Add(this.activeTextBox);
            this.Controls.Add(this.wakeUpTextBox);
            this.Controls.Add(this.bedTimeTextBox);
            this.Controls.Add(this.petsTextBox);
            this.Controls.Add(this.petsLabel);
            this.Controls.Add(this.roomateGenderLabel);
            this.Controls.Add(this.studyLabel);
            this.Controls.Add(this.guestsLabel);
            this.Controls.Add(this.wakeUpLabel);
            this.Controls.Add(this.bedTimeLabel);
            this.Controls.Add(this.activeLabel);
            this.Controls.Add(this.hobbiesRichTextBox);
            this.Controls.Add(this.yearTextBox);
            this.Controls.Add(this.hobbiesLabel);
            this.Controls.Add(this.yearLabel);
            this.Controls.Add(this.genderTextBox);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(this.majorTextBox);
            this.Controls.Add(this.emailTextBox);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.majorLabel);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.genderLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.matchButton);
            this.Controls.Add(this.profileButton);
            this.Controls.Add(this.homeButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form4";
            this.Text = "Profile";
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button matchButton;
        private System.Windows.Forms.Button profileButton;
        private System.Windows.Forms.Button homeButton;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox genderTextBox;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.TextBox majorTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label majorLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.RichTextBox hobbiesRichTextBox;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.Label hobbiesLabel;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.TextBox genderPrefTextBox;
        private System.Windows.Forms.TextBox studyTextBox;
        private System.Windows.Forms.TextBox guestsTextBox;
        private System.Windows.Forms.TextBox activeTextBox;
        private System.Windows.Forms.TextBox wakeUpTextBox;
        private System.Windows.Forms.TextBox bedTimeTextBox;
        private System.Windows.Forms.TextBox petsTextBox;
        private System.Windows.Forms.Label petsLabel;
        private System.Windows.Forms.Label roomateGenderLabel;
        private System.Windows.Forms.Label studyLabel;
        private System.Windows.Forms.Label guestsLabel;
        private System.Windows.Forms.Label wakeUpLabel;
        private System.Windows.Forms.Label bedTimeLabel;
        private System.Windows.Forms.Label activeLabel;
        private System.Windows.Forms.PictureBox profilePictureBox;
        private System.Windows.Forms.Button editPhotoButton;
    }
}